import React from 'react'
import Body from './Body'

const Home = () => {
  return (
    <div className="text-black">
      {/* 메인 홈 */}

      {/* 4가지 보여질것들 */}
      <Body />
      </div>
  )
}

export default Home