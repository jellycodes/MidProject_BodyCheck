import React from 'react'
import Body from './Body'
import Header from './Header'

const Home = () => {
  return (
    <div className="text-black">
      {/* 메인 홈 */}
      <img className="w-full h-auto" src="bodyinfo_bg.png" />
      {/* 4가지 보여질것들 */}
      <Body />
      </div>
  )
}

export default Home