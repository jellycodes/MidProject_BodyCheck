import React from 'react'

const Body = () => {
  return (

    <div className='bg-orange-300'>
      Body
      {/* 4가지 보여질것들 */}
      </div>
  )
}

export default Body