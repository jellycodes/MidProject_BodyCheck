import React from 'react'
// import BoardList from '../Posts/board-category/BoardList'
import List from '../Posts/board-category/List';
import { Link } from 'react-router-dom';


const products = [
  {
    id: 1,
    name: '임팩트 웨이 프로틴',
    href: 'https://www.myprotein.co.kr/sports-nutrition/impact-whey-protein/10530943.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp/productimg/1600/1600/10530943-1234625356041867.jpg',
    price: '₩20,900',
    rate: '★★★★★',
  },
  {
    id: 2,
    name: '클리어 웨이 아이솔레이트',
    href: 'https://www.myprotein.co.kr/sports-nutrition/clear-whey-isolate/12081395.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/12700582-2594853678982912.jpg',
    price: '₩39,900',
    rate: '★★★★☆',
  },
  {
    id: 3,
    name: '임팩트 웨이 아이솔레이트',
    href: 'https://www.myprotein.co.kr/sports-nutrition/impact-whey-isolate/10530911.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/10530911-5884889444360331.jpg',
    price: '₩49,900',
    rate: '★★★★★',
  },
  {
    id: 4,
    name: '식물성 프로틴 블렌드',
    href: 'https://www.myprotein.co.kr/sports-nutrition/vegan-protein-blend/11776868.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/11776868-2774835585006253.jpg',
    price: '₩29,900',
    rate: '★★★★☆',
  },
  // More products...
]

const Body = (props) => {
  return (
    <>
      <div className="flex px-4 py-4 mx-4 my-4 space-x-6">

        {/* 오늘의 헬창 */}
        <div className="justify-start lg:w-0 lg:flex-1">
          <div className='flex pb-1'>
            <img className='h-6 px-2 pt-2' src="barbell.png" />
            <h1 className='text-lg font-bold text-gray-800'>오늘의 헬창</h1>
          </div>
          <div className='w-auto border-2 border-dotted rounded-lg border-neutral-300 hover:border-solid h-72'>
          <a href='https://www.instagram.com/p/CjVes7bJ9m_/?hl=ko'>
            <img  className='px-20 pt-20 h-60' src="Insta_image.png" />
          </a>
          </div>
        </div>

        {/* 최근 게시물 */}
        <div className="justify-start lg:w-0 lg:flex-1">
          <div className='flex pb-1'>
            <img className='h-6 px-2 pt-2' src="barbell.png" />
            <h1 className='text-lg font-bold text-gray-800'>최근 게시물</h1>
          </div>
          <div className='w-auto border-2 border-dotted rounded-lg border-violet-700 hover:border-solid h-72'>
            <table>
              <thead>
                <Link to='/boards'>

                  <th className='px-6 py-2 text-xs text-yellow-600'>게시글 번호</th>
                  <th className='text-xs text-yellow-600 px-30 py-30'>제목</th>
                  <th className='px-6 py-2 text-xs text-yellow-600'>내용</th>

                </Link>
              </thead>
            </table>
          </div>
        </div>

        {/* 오운완 챌린지 */}
        <div className="lg:w-0 lg:flex-1">
          <div className='flex pb-1'>
            <img className='h-6 px-2 pt-2' src="barbell.png" />
            <h1 className='text-lg font-bold text-gray-800'>오운완 챌린지</h1>
          </div>
          <div className='flex mt-2 space-x-4'>
            {/* {weeks.map((today,index) => <Button key={today} date={today} isSelected={isCategorySelect[index]} handleClick={clickHandler} elementIndex={index}/>)} */}
          </div>
          <img className='h-56 px-2 my-6' src="calendar.png" />
        </div>

      </div>

      {/* 인기 프로틴 */}
      <div className="flex px-4 mx-4 my-4 mb-4 space-x-10">
        <div className="justify-start lg:w-0 lg:flex-1">

          <div className='flex pb-1'>
            <img className='h-6 px-2 pt-2' src="barbell.png" />
            <h1 className='text-lg font-bold text-gray-800'>인기 프로틴</h1>
          </div>

          <div className='w-auto border-2 border-dotted rounded-lg border-neutral-300'>
            <div className="grid grid-cols-1 mx-4 my-4 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
              {products.map((product) => (
                <div key={product.id} className="relative group">
                  <div className="w-full overflow-hidden bg-gray-200 rounded-md min-h-80 aspect-w-1 aspect-h-1 group-hover:opacity-75 lg:aspect-none lg:h-80">
                    <img
                      src={product.imageSrc}
                      className="object-cover object-center w-full h-full lg:h-full lg:w-full"
                      onClick={() => product.href}
                    />
                  </div>
                  <div className="flex justify-between mt-4">
                    <div className='text-left'>
                      <h3 className="text-sm text-gray-700">
                        <a href={product.href}>
                          <span aria-hidden="true" className="absolute inset-0" />
                          {product.name}
                        </a>
                      </h3>
                      <p className="mt-0 text-sm text-gray-500">{product.rate}</p>
                    </div>
                    <p className="text-sm font-medium text-gray-900">{product.price}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

    </>
  )
}

export default Body