import React from 'react'

const Header = () => {
  return (
    <div className='bg-blue-200'>
      Header
      {/* 메뉴 바 */}
      </div>
  )
}

export default Header