import React from 'react'
import { Popover } from '@headlessui/react'
import { Link } from 'react-router-dom'

const Header = () => {
    return (
        <Popover className="relative bg-white">
            <div className="px-4 mx-4 sm:px-6">
                <div className="flex items-center justify-between py-1 border-b-2 border-gray-100 md:justify-start md:space-x-10">

                    <div className="flex justify-start lg:w-0 lg:flex-1">
                        <Link to="/">
                            <span className="sr-only">Your Company</span>
                            <img
                                className="w-auto h-10 sm:h-20"
                                src="bodyinfo_logo.png"
                                alt="logo"
                            />
                        </Link>
                    </div>

                    <Popover.Group as="nav" className="hidden space-x-16 md:flex">
                        <Link to="/boards" className="text-base font-medium text-gray-500 hover:text-gray-900">
                            자유게시판
                        </Link>
                        <Link to="/Product" className="text-base font-medium text-gray-500 hover:text-gray-900">
                            스토어
                        </Link>
                        <Link to="/Calendar" className="text-base font-medium text-gray-500 hover:text-gray-900">
                            오운완
                        </Link>
                        <Link to="/Howtoworkout" className="text-base font-medium text-gray-500 hover:text-gray-900">
                            운동법
                        </Link>
                    </Popover.Group>

                    <div className="items-center justify-end hidden md:flex md:flex-1 lg:w-0">
                        <Link to="#" className="text-base font-medium text-gray-500 whitespace-nowrap hover:text-gray-900">
                            회원가입
                        </Link>
                        <Link
                            to="#"
                            className="inline-flex items-center justify-center px-4 py-2 ml-8 text-base font-medium text-white border border-transparent rounded-md shadow-sm whitespace-nowrap bg-neutral-900 hover:bg-neutral-600"
                        >
                            로그인
                        </Link>
                    </div>

                </div>
            </div>

            {/* <img className="w-full h-auto" src="bodyinfo_bg.png" /> */}

        </Popover>
    )
}

export default Header