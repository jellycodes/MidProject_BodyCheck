import React, { useEffect, useState } from 'react'
// 예제파일
const Hello = () => {
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch('/hello')
      .then(response => response.text())
      .then(message => {
        setMessage(message);
        console.log(message);
      });
  }, [])

  return <h1 className="text-3xl font-bold ">{message}</h1>
}

export default Hello