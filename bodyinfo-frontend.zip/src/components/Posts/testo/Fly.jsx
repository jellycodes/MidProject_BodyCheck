import React from 'react'

const Fly = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\Fly.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Fly</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>벤치에 등을 대고 누운 뒤 손바닥을 서로 마주보게 덤벨을 잡아, 가슴 위로 양팔을 쭉 밀어올립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>팔꿈치는 자연스럽게 살짝 구부리면서 가슴 옆방향으로 팔을 천천히 펼쳐줍니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>팔로 반원을 그리며 덤벨을 모아 시작 자세로 돌아옵니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Fly