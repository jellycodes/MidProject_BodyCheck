import React from 'react'

const PushUp = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\PushUp.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Push Up</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>양팔을 가슴 옆에 두고 바닥에 엎드립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>복근과 둔근에 힘을 준 상태로 팔꿈치를 피며 올라옵니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>천천히 팔꿈치를 굽히며 시작 자세로 돌아갑니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default PushUp