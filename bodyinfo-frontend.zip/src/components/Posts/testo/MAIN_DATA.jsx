export const MAIN_DATA = [
    {
        id: 1,
        text: '런지',
        name: 'Lunge',
    },
    {
        id: 2,
        text: '스쿼트',
        name: 'Squat',
    },
    {
        id: 3,
        text: '턱걸이',
        name: 'PullUp',
    },
    {
        id: 4,
        text: '렛폴다운',
        name: 'LatPullDown',
    },
    {
        id: 5,
        text: '시티드 케이블 로우',
        name: 'SittedCableRow',
    },
    {
        id: 6,
        text: '싯업',
        name: 'SitUp',
    },
    {
        id: 7,
        text: 'AB롤아웃',
        name: 'ABrollout',
    },
    {
        id: 8,
        text: '레터럴 레이즈',
        name: 'LateralRaise',
    },
    {
        id: 9,
        text: '업라이트 로우',
        name: 'UpRightRow',
    },
    {
        id: 10,
        text: '덤벨 컬',
        name: 'DumbbellCurl',
    },
    {
        id: 11,
        text: '푸쉬업',
        name: 'PushUp',
    },
    {
        id: 12,
        text: '딥스',
        name: 'Dips',
    },
    {
        id: 13,
        text: '플라이',
        name: 'Fly',
    },

];

