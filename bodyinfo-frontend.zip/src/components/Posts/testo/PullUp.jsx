import React from 'react'

const PullUp = () => {
  return (
    <div className='flex justify-center'>
      <img className="max-w-sm pl-10 m-10" src="gif\PullUp.gif"></img>
      <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
        <div className='m-auto text-left'>
          <h3 className='my-3 text-2xl font-bold text-slate-700'>Pull Up</h3>
          <div className='flex my-4'>
            <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
            <p>양발을 골반 너비만큼 벌리고 상체를 곧게 펴고 섭니다</p>
          </div>
          <div className='flex my-4'>
            <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
            <p>한쪽 다리를 뻗어 앞으로 나아가면서 두 무릎이 90도 각도를 이룰때까지 엉덩이를 낮춰줍니다. 이때 상체와 등은 곧게 편 자세를 유지합니다.</p>
          </div>
          <div className='flex my-4'>
            <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
            <p>앞발의 뒤꿈치에 무게 중심을 실어서 몸을 위쪽으로 밀어주며 원래 시작 자세로 돌아옵니다.</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PullUp