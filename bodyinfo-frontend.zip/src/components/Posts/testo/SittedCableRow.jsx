import React from 'react'

const SittedCableRow = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\SittedCableRow.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Sitted Cable Row</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>의자에 앉아 상체를 고정하고 손잡이를 양손으로 잡습니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>허리를 펴고 가슴을 내민 상태에서, 등 중앙부를 접는다는 느낌으로 팔꿈치를 몸에 붙여 당깁니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>등의 긴장감을 유지하며 천천히 팔을 펴줍니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default SittedCableRow