import React from 'react'

const LateralRaise = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\LateralRaise.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Lateral Raise</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>양발을 어깨너비로 적당히 벌리고, 가슴을 편상태로 덤벨을 잡습니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>측면 어깨(삼각근)에 자극을 느끼면서 팔꿈치를 올린다는 생각으로 덤벨을 들어 올립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>측면 삼각근의 자극을 느끼면서 천천히 팔을 내립니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default LateralRaise