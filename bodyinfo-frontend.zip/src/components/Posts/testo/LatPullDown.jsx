import React from 'react'

const LatPullDown = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\LatPullDown.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Lat Pull Down</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>허벅지 지지대의 높낮이를 알맞게 조절하고, 바를 어깨너비보다 넓게 잡고 의자에 앉습니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>허벅지를 지지대에 고정하고 가슴을 편상태로, 바가 쇄골에 닿을 정도로 바를 당겨줍니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>광배근이 이완하는 것을 느끼면서 천천히 팔을 폅니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default LatPullDown