import React from 'react'

const Squat = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\Squat.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Squat</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>다리를 어깨 넓이로 하고 허리를 곧게 세워 유지한 채 천천히 주저앉으며 내려간다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>내려가는 동안 무릎이 발가락 끝을 넘어가지 않도록 하며 무릎의 각도가 90도가 되는 순간 멈춘다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>다시 일어서며 마찬가지로 몸에 긴장을 유지한 채 허리가 구부러지지 않도록 일어선다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Squat