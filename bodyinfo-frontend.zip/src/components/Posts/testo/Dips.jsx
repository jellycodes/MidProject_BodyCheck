import React from 'react'

const Dips = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\Dips.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Dips</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>딥스바의 폭을 어깨보다 살짝 넓게 셋팅한 상태에서, 손목이 꺾이지 않게 딥스바에 올라갑니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>상체는 살짝 앞으로 기울인 상태로 팔꿈치가 90도가 될때까지 팔을 굽혀 몸을 내립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>상체의 균형을 유지한 채로 팔을 피면서 올라옵니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Dips