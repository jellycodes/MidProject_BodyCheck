import React from 'react'

const DumbbellCurl = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\DumbbellCurl.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Dumbbell Curl</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>양발을 어깨너비로 적당히 벌리고 양손에 덤벨을 잡습니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>이두근으로만 덤벨을 들어올린다는 생각으로 팔을 구부립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>구부린 팔을 펴면서 시작 자세로 돌아갑니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default DumbbellCurl