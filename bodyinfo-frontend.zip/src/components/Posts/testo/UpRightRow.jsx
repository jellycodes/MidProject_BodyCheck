import React from 'react'

const UpRightRow = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\UpRightRow.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>Up Right Row</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>바벨을 어깨너비보다 살짝 좁게 잡고, 허벅지 위에 살짝 올려둡니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>팔꿈치를 양옆으로 활짝 벌린다는 생각으로 바벨을 들어 올립니다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>어깨의 자극을 유지하면서 천천히 내려 1번의 자세로 돌아옵니다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default UpRightRow