import React from 'react'

const ABrollout = () => {
  return (
    <div className='flex justify-center'>
    <img className="max-w-sm pl-10 m-10" src="gif\ABRollOut.gif"></img>
    <div className="max-w-6xl px-10 py-3 mx-10 my-10 border-4 border-gray-200 border-dashed rounded-lg h-96 lg:h-full" >
      <div className='m-auto text-left'>
        <h3 className='my-3 text-2xl font-bold text-slate-700'>AB RollOut</h3>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>01</p>
          <p>바닥에 무릎을 꿇고 기구를 잡는다. 이 때 허벅지는 수직으로 두는 것이 좋다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>02</p>
          <p>숨을 들이마쉬고 복근이 늘어나는 것을 느끼며 멀리까지 밀어준다.</p>
        </div>
        <div className='flex my-4'>
          <p className='mr-2 text-xl font-bold text-slate-400'>03</p>
          <p>복근을 수축시키면서 몸을 당겨준다. 몸을 앞으로 말아준다는 느낌으로 당기면 된다.</p>
        </div>
      </div>
    </div>
  </div>
  )
}

export default ABrollout