import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'

const Calendar = () => {
  return (
    <div>Calendar</div>

  )
}

export default Calendar