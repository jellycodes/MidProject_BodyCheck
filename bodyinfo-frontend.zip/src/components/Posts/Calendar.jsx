import React from 'react'

const Calendar = () => {
  return (
    <img src='image (2).png'></img>
    


  )
}

export default Calendar
