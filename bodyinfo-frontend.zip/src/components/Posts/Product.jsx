import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'

const Product = () => {
  return (
    <div>Product</div>
  )
}

export default Product