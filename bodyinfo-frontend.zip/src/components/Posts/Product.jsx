import React from 'react'

const proteins = [
  {
    id: 1,
    name: '임팩트 웨이 프로틴',
    href: 'https://www.myprotein.co.kr/sports-nutrition/impact-whey-protein/10530943.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp/productimg/1600/1600/10530943-1234625356041867.jpg',
    price: '₩20,900',
    rate: '★★★★★',
  },
  {
    id: 2,
    name: '클리어 웨이 아이솔레이트',
    href: 'https://www.myprotein.co.kr/sports-nutrition/clear-whey-isolate/12081395.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/12700582-2594853678982912.jpg',
    price: '₩39,900',
    rate: '★★★★☆',
  },
  {
    id: 3,
    name: '임팩트 웨이 아이솔레이트',
    href: 'https://www.myprotein.co.kr/sports-nutrition/impact-whey-isolate/10530911.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/10530911-5884889444360331.jpg',
    price: '₩49,900',
    rate: '★★★★★',
  },
  {
    id: 4,
    name: '식물성 프로틴 블렌드',
    href: 'https://www.myprotein.co.kr/sports-nutrition/vegan-protein-blend/11776868.html',
    imageSrc: 'https://static.thcdn.com/images/large/webp//productimg/1600/1600/11776868-2774835585006253.jpg',
    price: '₩29,900',
    rate: '★★★★☆',
  },
  // More proteins...
]

const health = [
  {
    id: 1,
    name: '팔꿈치 패드 스트랩',
    href: 'https://www.monsterzym.com/elbow-strap-w-pads-black-ko.html',
    imageSrc: 'https://cdn.monsterzym.com/images/detailed/19/McDavid_%ED%8C%94%EA%BF%88%EC%B9%98_%ED%8C%A8%EB%93%9C_%EC%8A%A4%ED%8A%B8%EB%9E%A9_%EA%B2%80%EC%A0%95%EC%83%891-1.jpg?t=1640872036',
    price: '₩24,079',
    rate: '★★★★★',
  },
  {
    id: 2,
    name: '무릎 보호대 오픈형',
    href: 'https://www.monsterzym.com/knee-support-w-open-patella-black-ko.html',
    imageSrc: 'https://cdn.monsterzym.com/images/detailed/10/%EB%AC%B4%EB%A6%8E_%EB%B3%B4%ED%98%B8%EB%8C%80_%EC%98%A4%ED%94%88%ED%98%95_%EA%B2%80%EC%A0%95%EC%83%89-1.jpg?t=1652074294',
    price: '₩20,538',
    rate: '★★★★★',
  },
  {
    id: 3,
    name: '안티-리퍼 장갑',
    href: 'https://www.monsterzym.com/f4-anti-ripper-glove-ko.html',
    imageSrc: 'https://cdn.monsterzym.com/images/detailed/10/%EC%95%88%ED%8B%B0-%EB%A6%AC%ED%8D%BC_%EC%9E%A5%EA%B0%911-1.jpg?t=1635411342',
    price: '₩27,266',
    rate: '★★★★☆',
  },
  {
    id: 4,
    name: '리프팅 스트랩',
    href: 'https://www.monsterzym.com/monsterzym-lifting-straps.html',
    imageSrc: 'https://cdn.monsterzym.com/images/detailed/32/%EB%AA%AC%EC%8A%A4%ED%84%B0%EC%A7%90_%EB%A6%AC%ED%94%84%ED%8C%85_%EC%8A%A4%ED%8A%B8%EB%9E%A9-1.jpg?t=1634283434',
    price: '₩7,790',
    rate: '★★★★☆',
  },
  // More proteins...
]

const Product = () => {
  return (
    <>
      {/* 단백질 보충제 */}
      <div className='w-auto mx-8 my-8 '>
        <h1 className='mx-2 mb-2 text-lg font-bold text-left text-gray-800'>단백질 보충제</h1>
        <div className='w-auto border-2 border-dotted rounded-lg border-neutral-300'>
          <div className="grid grid-cols-1 mx-4 my-4 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
            {proteins.map((product) => (
              <div key={product.id} className="relative group">
                <div className="w-full overflow-hidden bg-gray-200 rounded-md min-h-80 aspect-w-1 aspect-h-1 group-hover:opacity-75 lg:aspect-none lg:h-80">
                  <img
                    src={product.imageSrc}
                    className="object-cover object-center w-full h-full lg:h-full lg:w-full"
                    onClick={product.href}
                  />
                </div>
                <div className="flex justify-between mt-4">
                  <div className='text-left'>
                    <h3 className="text-sm text-gray-700">
                      <a href={product.href}>
                        <span aria-hidden="true" className="absolute inset-0" />
                        {product.name}
                      </a>
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">{product.rate}</p>
                  </div>
                  <p className="text-sm font-medium text-gray-900">{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* 헬스 용품 */}
      <div className='w-auto mx-8 my-8 '>
        <h1 className='mx-2 mb-2 text-lg font-bold text-left text-gray-800'>헬스 용품</h1>
        <div className='w-auto border-2 border-dotted rounded-lg border-neutral-300'>
          <div className="grid grid-cols-1 mx-4 my-4 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
            {health.map((product) => (
              <div key={product.id} className="relative group">
                <div className="w-full overflow-hidden bg-gray-200 rounded-md min-h-80 aspect-w-1 aspect-h-1 group-hover:opacity-75 lg:aspect-none lg:h-80">
                  <img
                    src={product.imageSrc}
                    className="object-cover object-center w-full h-full lg:h-full lg:w-full"
                    onClick={product.href}
                  />
                </div>
                <div className="flex justify-between mt-4">
                  <div className='text-left'>
                    <h3 className="text-sm text-gray-700">
                      <a href={product.href}>
                        <span aria-hidden="true" className="absolute inset-0" />
                        {product.name}
                      </a>
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">{product.rate}</p>
                  </div>
                  <p className="text-sm font-medium text-gray-900">{product.price}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}

export default Product