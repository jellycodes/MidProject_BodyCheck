import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'

const HowToWorkOut = () => {
  return (
    <div>HowToWorkOut</div>

  )
}

export default HowToWorkOut