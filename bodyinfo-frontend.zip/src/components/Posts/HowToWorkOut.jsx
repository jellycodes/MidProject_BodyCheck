import { useState } from 'react'
import { Disclosure,  } from '@headlessui/react'
import { MinusIcon, PlusIcon } from '@heroicons/react/20/solid'
import ABrollout from '../Posts/testo/ABrollout';
import Lunge from '../Posts/testo/Lunge';
import Squat from './testo/Squat';
import PullUp from './testo/PullUp';
import LatPullDown from './testo/LatPullDown';
import SittedCableRow from './testo/SittedCableRow';
import SitUp from './testo/SitUp';
import LateralRaise from './testo/LateralRaise';
import UpRightRow from './testo/UpRightRow';
import DumbbellCurl from './testo/DumbbellCurl';
import PushUp from './testo/PushUp';
import Fly from './testo/Fly';
import Dips from './testo/Dips';


const filters = [
  {
    id: 'leg',
    name: '하체',
    options: [
      { value: '런지', label: 'Lunge', checked: false },
      { value: '스쿼트', label: 'Squat', checked: false },
    ],
  },
  {
    id: 'back',
    name: '등',
    options: [
      { value: '턱걸이', label: 'PullUp', checked: false },
      { value: '렛 풀 다운', label: 'LatPullDown', checked: false },
      { value: '시티드 케이블 로우', label: 'SittedCableRow', checked: false },
    ],
  },
  {
    id: 'stomach',
    name: '복부',
    options: [
      { value: '싯업', label: 'SitUp', checked: false },
      { value: 'AB롤아웃', label: 'ABrollout', checked: false },
    ],
  },
  {
    id: 'shoulder',
    name: '어깨',
    options: [
      { value: '레터럴 레이즈', label: 'LateralRaise', checked: false },
      { value: '업라이트 로우', label: 'UpRightRow', checked: false },
    ],
  },
  {
    id: 'arm',
    name: '팔',
    options: [
      { value: '덤벨 컬', label: 'DumbbellCurl', checked: false },

    ],
  },
  {
    id: 'chest',
    name: '가슴',
    options: [
      { value: '푸쉬업', label: 'PushUp', checked: false },
      { value: '딥스', label: 'Dips', checked: false },
      { value: '플라이', label: 'Fly', checked: false },

    ],
  },
]


const HowToWorkOut = () => {

  const [content, setContent] = useState();

  const handleClickButton = e => {
    e.preventDefault();
    const { name } = e.target;
    setContent(name);
  };

  const selectComponent = {
    Lunge: <Lunge />,
    Squat: <Squat/>,
    PullUp: <PullUp/>,
    LatPullDown: <LatPullDown />,
    SittedCableRow: <SittedCableRow/>,
    SitUp: <SitUp/>,
    ABrollout: <ABrollout />,
    LateralRaise: <LateralRaise/>,
    UpRightRow: <UpRightRow/>,
    DumbbellCurl: <DumbbellCurl />,
    PushUp: <PushUp/>,
    Dips: <Dips/>,
    Fly: <Fly/>,
  };

  return (
    <div className="bg-white">
      <div>
        <main className="px-4 mx-16 mt-3 sm:px-6 lg:px-4">
          <div className="flex items-baseline justify-between py-5 border-b border-gray-200 mx-7">
            <h1 className="pl-3 text-2xl font-bold tracking-tight text-gray-900">신체 부위별 운동법</h1>
          </div>
          <section aria-labelledby="products-heading" className="py-2 pb-24">
            <div>
              {/* Filters */}
              <form className="flex justify-center mx-3">
                {filters.map((section) => (
                  <Disclosure as="div" key={section.id} className="px-2 py-6 border-b border-gray-200">
                    {({ open }) => (
                      <>
                        <h3 className="flow-root -my-3">
                          <Disclosure.Button className="flex items-center justify-between w-full px-10 py-3 space-x-8 text-sm text-gray-400 bg-gray-100 rounded-full hover:border-2 hover:border-gray-400">
                            <span className="text-lg font-semibold text-gray-800">{section.name}</span>
                            <span className="flex items-center pl-10 ">
                              {open ? (
                                <MinusIcon className="w-5 h-5" aria-hidden="true" />
                              ) : (
                                <PlusIcon className="w-5 h-5" aria-hidden="true" />
                              )}
                            </span>
                          </Disclosure.Button>
                        </h3>
                        <Disclosure.Panel className="pt-6">
                          <div className="px-4 py-3 mx-2 space-y-4 border-2 border-gray-200 border-dashed rounded-lg">
                            {section.options.map((option) => (
                              <div key={option.value} className="flex items-center">
                                <label className="ml-3 text-base text-gray-600 hover:font-bold">
                                  <button onClick={handleClickButton} name={option.label} key={option.label}>
                                    {option.value}
                                  </button>
                                </label>

                              </div>
                            ))}
                          </div>
                        </Disclosure.Panel>
                      </>
                    )}
                  </Disclosure>
                ))}
              </form>
              <div className="lg:col-span-3">
                  {content && <div>{selectComponent[content]}</div>}
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  )
}

export default HowToWorkOut