import React, { useState, useEffect } from 'react'
import axios from 'axios'


const WriteBoard = () => {
  return (
    <div>
      <h1>게시물작성페이지</h1>

      initialValues={{
        id: '',
        title: '',
        content: '',

      }}
      onSubmit={values => {

        const { id, title, content } = values;

        const submitValue = {
          id,
          title,
          content
        }
        console.log(submitValue);
        const options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(submitValue),
        };

        fetch('http://localhost:8090/boards', options)
          .then(response => response.json())
          .then(data => console.log(data))
          .catch(error => console.error('실패', error));

        router.push('/');
      }}
      {
        ({ values, errors, touched, handleSubmit, handleChange, handleBlur, isSubmitting }) => (
          <div className='mt-10 sm:mt-0'>
            <div className='md:grid md:grid-cols-3 md:gap-6'>
              <div className='mt-5 md:col-span-2 md:mt-0'>
                <form onSubmit={handleSubmit}>
                  <div className='overflow-hidden shadow sm:rounded-md'>
                    <div className='px-4 py-5 bg-white sm:p-6'>
                      <div className='grid grid-cols-6 gap-6'>
                        {/* Title */}
                        <input type='text'
                          // default attributes
                          id='title' name='title'
                          htmlFor='title' labelText='title' placeholder='제목을 입력하세요'
                          // Formik Validating
                          value={values.title}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          // tailwindcss
                          divClassName='col-span-6 sm:col-span-3'
                          labelClassName='block text-sm font-medium text-gray-700'
                          inputClassName='mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm'
                        />
                        {/* Content */}
                        <input type='text' id='content' name='content'
                          htmlFor='content' labelText='content' placeholder='내용을 입력하세요'
                          value={values.content}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          divClassName='col-span-6 sm:col-span-3'
                          labelClassName='block text-sm font-medium text-gray-700'
                          inputClassName='mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm' />
                      </div>
                      <div className='px-4 py-3 text-right bg-gray-50 sm:px-6'>
                        <button type='submit' className='inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md whadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>작성</button>
                        <button type='delete' className='inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md whadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>삭제</button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )
      }
    </div>
  )
}

export default WriteBoard