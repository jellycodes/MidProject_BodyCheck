import React, { useState, useEffect } from 'react'
import axios from 'axios'


function BoardList() {
  const [boards, setBoards] = useState([]);
  useEffect(() => {
    axios
      .get('http://localhost:8090/boards')
      .then((response) => {
        setBoards(response.data)
      }).catch(error => {
        console.log(error)
      })
  }, []);
  return (

    <table>
      <thead>
        <tr>
          <th className='col-lg-2'>글번호</th>
          <th className='col-lg-2'>제목</th>
          <th className='col-lg-8'>내용</th>
        </tr>
      </thead>
      <tbody>
        {boards.map((board) => {
          return (
            <tr key={board.id}>
              <th>{board.id}</th>
              <th>{board.title}</th>
              <th>{board.content}</th>
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}
export default BoardList