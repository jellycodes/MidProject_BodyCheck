import React, { useState, useEffect } from 'react'
import axios from 'axios'


function DataFetching() {
  const [id, setId] = useState(1)
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [idFromButtonClick, setIdFromButtonClick] = useState(1)

  const handleClick =() => {
    setIdFromButtonClick(id)
  }

  useEffect(() => {
    axios
      .get(`http://localhost:8090/boards/${id}`)
      .then((response) => {
        
        console.log(response.data);
        setTitle(response.data.title);
        setContent(response.data.content);
      }).catch(error => {
        console.log(error)
      })
  }, [])
  return (
    
    <div>
      title
      <input type="text" value={title} onChange={(event) => setTitle(event.target.value)} /><br></br>
      
      content
      <input type="text" value={content} onChange={(event) => setContent(event.target.value)} />
      

      {/* {boards.map(board => (
          <tr key={board.id}>
              <th>{board.id}</th>
              <th>{board.title}</th>
              <th>{board.content}</th></tr>
        ))} */}
      
        <button type='submit' onClick={handleClick} className='inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md whadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>작성</button>
        <button type='delete' onClick={handleClick} className='inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md whadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'>삭제</button>
      
    </div>
    
  )
}
export default DataFetching