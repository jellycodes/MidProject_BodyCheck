import React from 'react'
import { Link } from 'react-router-dom'

let navigation = [
  //   { name: 'Boards', href: '/boards/list' },
    // { name: 'board', href: '/boards' },

]

const Board = () => {

  return (
    <>
      <div className="text-center">
        
          <div className="text-left">
            
              <Link to="/">
                  <img
                    alt="Your Company"
                    className="w-12 h-12"
                    src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600"
                  />
              </Link>
            
          </div>
          <div className="hidden text-xl md:ml-10 md:block md:space-x-8 md:pr-4">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href} className="font-semibold text-gray-500 hover:text-gray-700 inline-block relative after:absolute after:w-full after:transform after:scale-x-0 after:h-[2px] after:bottom-0 after:left-0 after:bg-indigo-500 after:origin-bottom-right after:transition after:duration-[200ms] after:ease-out hover:after:scale-x-[(2)] hover:after:origin-bottom-left">
                  {item.name}
              </Link>
            ))}
            <Link to="/BoardList" className="font-medium text-indigo-600 hover:text-indigo-500">게시글 목록
            </Link>
            <Link to="/WriteBoard" className="font-medium text-indigo-600 hover:text-indigo-500">게시글 작성
            </Link>
            <Link to="/ModifyBoard" className="font-medium text-indigo-600 hover:text-indigo-500">게시글 수정
            </Link>

          </div>
        
      </div>
      <div className="overflow-hidden bg-white rounded-lg shadow-md ring-1 ring-black ring-opacity-5">
        <div className="px-2 pt-2 pb-3 space-y-1">
          {navigation.map((item) => (
              key={key},
              href={href},
              className="block px-3 py-2 text-base font-medium text-gray-700 rounded-md hover:bg-gray-50 hover:text-gray-900"
            >
              {item,}
          ))}
        </div>
      </div>
    </>
  )
}

export default Board