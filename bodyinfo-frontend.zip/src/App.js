import './index.css';
import Hello from './components/categories/Hello';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/categories/Home';
import Board from './components/Posts/Board';
import Product from './components/Posts/Product';
import Calendar from './components/Posts/Calendar';
import HowToWorkOut from './components/Posts/HowToWorkOut';
import BoardList from './components/Posts/board-category/BoardList';
import WriteBoard from './components/Posts/board-category/WriteBoard';
import ModifyBoard from './components/Posts/board-category/ModifyBoard';
import List from './components/Posts/board-category/List';
import Header from './components/categories/Header';

function App() {
  return (
    <>
      <div className="text-center">
        <BrowserRouter>
          {/* Header 부분 */}
          <Header />
          {/* 라우터 경로 설정 */}
          <Routes>
            {/* Home */}
            <Route path="/" element={<Home />} />
            
            {/* Hello 예제 */}
            <Route path="/hello" element={<Hello />} />
            
            {/* Posts */}
            <Route path="/boards" element={<Board />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/howtoworkout" element={<HowToWorkOut />} />
            <Route path="/product" element={<Product />} />
            
            {/* board-category */}
            <Route path="/List" element={<List />} />
            <Route path="/BoardList" element={<BoardList />} />
            <Route path="/WriteBoard" element={<WriteBoard />} />
            <Route path="/ModifyBoard" element={<ModifyBoard />} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
