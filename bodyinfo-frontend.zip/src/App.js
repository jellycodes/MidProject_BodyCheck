import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import './index.css';

function App() {
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch('/api/hello')
      .then(response => response.text())
      .then(message => {
        setMessage(message);
      });
  }, [])
  return (
    <>
      <div className="text-center">
        <header className="flex flex-col items-center justify-center min-h-screen text-white bg-Ebony text-[calc(10vh+36px)]">
          <h1 className="text-3xl font-bold underline">
            메인화면입니다.
          </h1>
          <img src={logo} className="animate-spin-slow" alt="logo" />
          <h1 className="text-3xl font-bold ">{message}</h1>
        </header>
      </div>
    </>
  );
}

export default App;
