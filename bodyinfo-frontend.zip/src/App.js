import './index.css';
import Body from './components/categories/Body';
import Header from './components/categories/Header';
import Hello from './components/categories/Hello';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './components/categories/Home';
import Board from './components/Posts/Board';
import Product from './components/Posts/Product';
import Calendar from './components/Posts/Calendar';
import HowToWorkOut from './components/Posts/HowToWorkOut';
import BoardList from './components/Posts/board-category/BoardList';
import WriteBoard from './components/Posts/board-category/WriteBoard';
import ModifyBoard from './components/Posts/board-category/ModifyBoard';

function App() {
  return (
    <>
      <div className="text-center">
      <BrowserRouter>
          {/* Header 부분 */}
          <Header />
          {/* 라우터 경로 설정 */}
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/hello" element={<Hello />} />
              <Route path="/boards" element={<Board />} />
              <Route path="/BoardList" element={<BoardList />} />
              <Route path="/WriteBoard" element={<WriteBoard />} />
              <Route path="/ModifyBoard" element={<ModifyBoard />} />
              <Route path="/product" element={<Product />} />
              <Route path="/calendar" element={<Calendar />} />
              <Route path="/howtoworkout" element={<HowToWorkOut />} />
            </Routes>
          {/* Body 부분 */}
          
        </BrowserRouter>
      </div>
    </>
  );
}

export default App;
