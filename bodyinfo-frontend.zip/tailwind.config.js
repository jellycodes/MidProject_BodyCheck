/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        'Ebony': '#282c34'
      },
      animation: {
        'spin-slow': 'spin 20s linear infinite'
      }
    },
  },
  plugins: [],
}
